let config = {
    width: 1200,
    numColumns: 14,
    transitionDuration: 500,
    transitionDelay: 8
};
